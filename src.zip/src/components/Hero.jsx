import hero from "../assets/hero.png";
import "../styles/Hero.css";

function Hero() {
    return (
        <section className="hero">

            <div className="hero-text">

                <h1>AI Powered Crop Disease Detection</h1>

                <p>
                    Upload a crop leaf image and detect diseases instantly using
                    Artificial Intelligence.
                </p>

                <div className="upload-box">

                    <input
                        type="file"
                        id="fileUpload"
                        hidden
                    />

                    <label htmlFor="fileUpload" className="browse-btn">
                        📂 Browse Files
                    </label>

                    <button className="detect-btn">
                        Detect Disease
                    </button>

                </div>

            </div>

            <div className="hero-image">
                <img
                    src={hero}
                    alt="Crop Disease Detection"
                />
            </div>

        </section>
    );
}

export default Hero;